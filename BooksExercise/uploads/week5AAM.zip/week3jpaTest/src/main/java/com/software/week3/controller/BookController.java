package com.software.week3.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.software.week3.entity.Author;
import com.software.week3.entity.Book;
import com.software.week3.entity.Category;
import com.software.week3.repository.AuthorRepository;
import com.software.week3.repository.BookRepository;
import com.software.week3.repository.CategoryRepository;

@Controller
public class BookController {
	@Autowired
	private BookRepository bookRepo;
	@Autowired
	private CategoryRepository catRepo;
	@Autowired
	private AuthorRepository authRepo;
	
	@GetMapping("/books")
	public String showBooks(Model model)
	{	
		List<Book> books = bookRepo.findAll();
		model.addAttribute("books", books);
		model.addAttribute("title", "All books");
		return "books";
	}
	
	
	@GetMapping("/books/newform")
	public String showBookForm(Model model)
	{
		model.addAttribute("book", new Book());
		model.addAttribute("title", "New Book");
		List<Category> categories = catRepo.findAll();
		List<Author> authors = authRepo.findAll();
		model.addAttribute("categories", categories);
		model.addAttribute("authors", authors);
		return "book";
	}
	@PostMapping("/books/save")
	public String saveBook(@Valid Book book,
			BindingResult result,
			@RequestParam("picture")MultipartFile pfile,
			Model model) throws IOException
	{	
		if (result.hasErrors())
		{	List<Category> categories = catRepo.findAll();
			List<Author> authors = authRepo.findAll();
			model.addAttribute("categories", categories);
			model.addAttribute("authors", authors);
			//model.addAttribute("books",book);
			return "book";
			
		}
		else {
			String fname = StringUtils.cleanPath(pfile.getOriginalFilename());
			
			String uploadDir ="uploads/";
			book.setImg(uploadDir+fname);
			Path fpath = Paths.get(uploadDir);
			Path uploadedFile= null;
			if (!Files.exists(fpath))
				{
				 Path  upPath=Files.createDirectories(fpath);
				 uploadedFile =upPath.resolve(fname);
				 Files.copy(pfile.getInputStream(), uploadedFile,StandardCopyOption.REPLACE_EXISTING);
				}
			else {
				uploadedFile = fpath;
			// store the uploaded file into  that path
				 uploadedFile =uploadedFile.resolve(fname);
			// store the uploaded file onto the server 
			Files.copy(pfile.getInputStream(), uploadedFile,StandardCopyOption.REPLACE_EXISTING);
			bookRepo.save(book);
			
			}
			return "success";
			
			
		}
	}

}
