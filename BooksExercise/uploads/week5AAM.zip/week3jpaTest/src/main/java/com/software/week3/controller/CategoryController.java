package com.software.week3.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.software.week3.entity.Category;
import com.software.week3.repository.CategoryRepository;

@Controller
public class CategoryController {
	@Autowired
	private CategoryRepository crepo;
	
	@GetMapping("/categories/newform")
	public String showCategoryForm(Model model)
	{	model.addAttribute("title", "New Category Form");
		model.addAttribute("category", new Category());
		return "category";
	}
	@PostMapping("/categoreis/save")
	public String saveCategory(Category category)
	{	
		crepo.save(category);
		return "success";
	}
	@GetMapping("/categories")
	public String showCategories(Model model)
	{	List<Category> categories = crepo.findAll();
		model.addAttribute("categories", categories);
		model.addAttribute("title", "All categories");
		return "categories";
	}
	

}
