package com.software.week3;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.software.week3.entity.Author;
import com.software.week3.entity.Book;
import com.software.week3.entity.Category;
import com.software.week3.repository.AuthorRepository;
import com.software.week3.repository.BookRepository;
import com.software.week3.repository.CategoryRepository;

@SpringBootApplication
public class Week3jpaTestApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(Week3jpaTestApplication.class, args);
	}
	@Autowired
	private CategoryRepository catRepo;
	@Autowired
	private BookRepository bookRepo;
	@Autowired
	private AuthorRepository authorRepo;
	@Override
	public void run(String... args) throws Exception {
		/*
		 * Author a1= new Author(); a1.setEmail("aaaa@gmail.com");
		 * a1.setName("Aye Aye"); a1.setPassword("111111");
		 * a1.setDateBirth(LocalDate.of(1978, 10, 21));
		 *  authorRepo.save(a1);// insert a1
		 * object into author table as one row
		 * 
		 * Category c1 = new Category(); c1.setName("Programming");
		 *  catRepo.save(c1);
		 * 
		 * Book b1 = new Book(); b1.setTitle("Java Design Patterns");
		 * b1.setIsbn("1000aaaa"); b1.setPrice(45.0f); b1.setAuthor(a1);
		 * b1.setCategory(c1); 
		 * bookRepo.save(b1);
		 */
	
		
		
		
	}

}
