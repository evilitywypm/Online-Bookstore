package com.software.week3.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.software.week3.entity.Author;
import com.software.week3.repository.AuthorRepository;
@Controller
public class AuthorController {
	
	@Autowired
	private AuthorRepository authRepo;
	
	@GetMapping("/authors/newform")
	public String showAuthorForm(Model model)
	{
		model.addAttribute("author", new Author());
		model.addAttribute("title", "New Author form");
		return "author";
	}
	@PostMapping("/authors/save")
	public String saveAuthor(Author author)
	{
		
		authRepo.save(author);
		return "success";
	}
	@GetMapping("/authors")
	public String showAuthors(Model model)
	{
		List<Author> authors = authRepo.findAll();
		model.addAttribute("authors", authors);
		model.addAttribute("title", "All authors list");
		return "authors";
		
	}
	
	

}
