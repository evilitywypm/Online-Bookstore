package com.software.week3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week3jpaTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
